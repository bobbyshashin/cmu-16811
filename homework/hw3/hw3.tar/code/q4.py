import numpy as np
from mpl_toolkits import mplot3d
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

clear_table = np.loadtxt('clear_table.txt')
cluttered_table = np.loadtxt('cluttered_table.txt')
cluttered_hallway = np.loadtxt('cluttered_hallway.txt')

print(clear_table.shape)
print(cluttered_table.shape)
print(cluttered_hallway.shape)

# x = np.zeros(101)
# for i in range(101):
#     x[i] = i / 10.0

# plt.plot(x, fx)
# plt.show()
clear_table = np.append(clear_table, np.ones((clear_table.shape[0], 1)), axis=1)
U1, S1, V1 = np.linalg.svd(clear_table, full_matrices=False)
print(S1)
c = V1[-1]
print(c)

# create x,y
x = np.linspace(0,3,3)
y = np.linspace(0,3,3)
xx, yy = np.meshgrid(x, y)
point = clear_table[0]
d = -point.dot(c)
# calculate corresponding z
z = -1.0 * (c[0] * xx + c[1] * yy + c[3]) / c[2]
# Create the figure
fig = plt.figure()

# Add an axes
ax = fig.add_subplot(111,projection='3d')

# plot the surface
# ax.plot_surface(xx, yy, z, alpha=1.0)

# and plot the point 
# ax.scatter(point2[0] , point2[1] , point2[2],  color='green')
# ax = plt.axes(projection='3d')

ax.plot3D(clear_table[:,0], clear_table[:,1], clear_table[:,2], 'gray')
# ax.plot3D(xx, yy, z, 'red')
plt.show()
